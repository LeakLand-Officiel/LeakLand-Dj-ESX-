Config = {}
Config.Range = 100.0  --< Range of Music >--
Config.Volume = 2   --< Music Volume Divider From 2 to 99 >-- --< 2 High Volume, 99 Low Volume >--
Config.nightclubs = {
	bahama_mamas = {
		dancefloor = {
			Pos = {x = -1386.41, y=  -618.57, z = 30.82},
			Marker = { w = 25.0, h = 1.0, r = 204, g = 204, b = 0},
		}, 
		djbooth = {
			Pos = {x = -1381.09, y = -616.22, z = 30.5}, 
			Marker = { w = 1.0, h = 0.5, r = 204, g = 204, b = 0},
		},
	},
}
Config.Job = 'clubdj'  --< Name of Job >--
Config.Grade = 0   --< Grade of Job >--
