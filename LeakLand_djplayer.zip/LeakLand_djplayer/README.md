# Lhdc_djplayer
DJ Job (Add-on for my script https://github.com/Gasparpereira2004/lhdc_DjJob)

						<------- By Gaspar Pereira - gaspar#0880 ------->

This is an addon/script (standalone) for mp3 player (like spotify) in game for DJ Job

	Instructions:
		1. Add to server.cfg "ensure lhdc_djplayer"
		2. Add your music to "lhdc_djplayer\html\sounds"  (.mp3 files)
		3. Add your music cover image to "lhdc_djplayer\html\sounds\covers"   (any image format)
		4. Add to "lhdc_djplayer\html\functions.js" (line 2) the number of music to use
		5. Add to "lhdc_djplayer\html\functions.js" (line 34) follow the template to your music/cover
		6. Thats it!

	Optional:
		In config.lua you can changer the music distance to listen
		You can change the music volume in config.lua
		
	The script go with 1 music, if you dont like, change by your music, and add your music
	
	THIS IS THE MP3 PLAYER 'ONLY' NOT JOB, you only make money if 
	have my lhdc_DjJob script (https://github.com/Gasparpereira2004/lhdc_DjJob)


![Captura de Ecrã (250)](https://user-images.githubusercontent.com/71574610/117226329-50995a00-ae0c-11eb-932d-b7f6c8bcbf6b.png)![Captura de Ecrã (251)](https://user-images.githubusercontent.com/71574610/117226335-5727d180-ae0c-11eb-9745-610717381813.png)

	If you have any bug/error open a issue or contact me in discord.
